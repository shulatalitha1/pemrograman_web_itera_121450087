from abc import ABC, abstractmethod

class LibraryItem(ABC):
    def __init__(self, item_id, title):
        self._id = item_id
        self._title = title

    @abstractmethod
    def display_info(self):
        pass

    @property
    def title(self):
        return self._title

    @property
    def id(self):
        return self._id

class Book(LibraryItem):
    def __init__(self, item_id, title, author):
        super().__init__(item_id, title)
        self._author = author

    def display_info(self):
        return f"[Book] ID: {self._id}, Title: {self._title}, Author: {self._author}"

class Magazine(LibraryItem):
    def __init__(self, item_id, title, issue):
        super().__init__(item_id, title)
        self._issue = issue

    def display_info(self):
        return f"[Magazine] ID: {self._id}, Title: {self._title}, Issue: {self._issue}"

class Library:
    def __init__(self):
        self.__items = []

    def add_item(self, item):
        if isinstance(item, LibraryItem):
            self.__items.append(item)
            print(f"Item '{item.title}' berhasil ditambahkan.")
        else:
            print("Hanya objek turunan LibraryItem yang bisa ditambahkan.")

    def show_all_items(self):
        if not self.__items:
            print("Belum ada item di perpustakaan.")
        else:
            print("\nDaftar Item di Perpustakaan:")
            for item in self.__items:
                print(item.display_info())

    def search_by_title(self, keyword):
        results = [item for item in self.__items if keyword.lower() in item.title.lower()]
        if results:
            print(f"\nHasil pencarian judul mengandung '{keyword}':")
            for item in results:
                print(item.display_info())
        else:
            print(f"\nTidak ditemukan item dengan judul mengandung '{keyword}'.")

    def search_by_id(self, item_id):
        for item in self.__items:
            if item.id == item_id:
                print(f"\nItem ditemukan dengan ID '{item_id}':")
                print(item.display_info())
                return
        print(f"\nTidak ditemukan item dengan ID '{item_id}'.")

library = Library()

book1 = Book("B001", "Python Programming", "Guido van Rossum")
magazine1 = Magazine("M001", "Science Weekly", "March 2025")

library.add_item(book1)
library.add_item(magazine1)

library.show_all_items()
library.search_by_title("python")
library.search_by_id("M001")