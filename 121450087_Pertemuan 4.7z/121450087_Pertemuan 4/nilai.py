# Program Pengelolaan Data Nilai Mahasiswa

# Data mahasiswa
mahasiswa = [
    {"nama": "Alya", "nim": "12345", "uts": 80, "uas": 85, "tugas": 75},
    {"nama": "Budi", "nim": "12346", "uts": 70, "uas": 65, "tugas": 60},
    {"nama": "Citra", "nim": "12347", "uts": 90, "uas": 95, "tugas": 85},
    {"nama": "Doni", "nim": "12348", "uts": 60, "uas": 55, "tugas": 65},
    {"nama": "Eva", "nim": "12349", "uts": 50, "uas": 45, "tugas": 55},
]

# Hitung nilai akhir dan tentukan grade
for m in mahasiswa:
    nilai_akhir = (0.3 * m['uts']) + (0.4 * m['uas']) + (0.3 * m['tugas'])
    m['nilai_akhir'] = nilai_akhir
    
    if nilai_akhir >= 80:
        m['grade'] = 'A'
    elif nilai_akhir >= 70:
        m['grade'] = 'B'
    elif nilai_akhir >= 60:
        m['grade'] = 'C'
    elif nilai_akhir >= 50:
        m['grade'] = 'D'
    else:
        m['grade'] = 'E'

# Tampilkan data dalam format tabel
print(f"\n{'Nama':<10} {'NIM':<10} {'UTS':<5} {'UAS':<5} {'Tugas':<7} {'Nilai Akhir':<12} {'Grade'}")
print("-" * 65)
for m in mahasiswa:
    print(f"{m['nama']:<10} {m['nim']:<10} {m['uts']:<5} {m['uas']:<5} {m['tugas']:<7} {m['nilai_akhir']:<12.2f} {m['grade']}")

# Cari nilai tertinggi dan terendah
nilai_tertinggi = max(mahasiswa, key=lambda x: x['nilai_akhir'])
nilai_terendah = min(mahasiswa, key=lambda x: x['nilai_akhir'])

print("\nMahasiswa dengan nilai tertinggi:")
print(f"{nilai_tertinggi['nama']} ({nilai_tertinggi['nim']}) - {nilai_tertinggi['nilai_akhir']:.2f}")

print("\nMahasiswa dengan nilai terendah:")
print(f"{nilai_terendah['nama']} ({nilai_terendah['nim']}) - {nilai_terendah['nilai_akhir']:.2f}")