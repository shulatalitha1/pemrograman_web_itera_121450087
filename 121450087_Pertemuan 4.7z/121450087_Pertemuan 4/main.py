# main.py

# Cara 1: Import seluruh modul
import math_operations as mo

# Cara 2: Import fungsi spesifik
from math_operations import celsius_ke_fahrenheit, celsius_ke_kelvin

# Menggunakan semua fungsi
print("=== Luas dan Keliling ===")
print(f"Luas persegi (sisi 4): {mo.luas_persegi(4)}")
print(f"Keliling persegi (sisi 4): {mo.keliling_persegi(4)}")

print(f"Luas persegi panjang (5x3): {mo.luas_persegi_panjang(5, 3)}")
print(f"Keliling persegi panjang (5x3): {mo.keliling_persegi_panjang(5, 3)}")

print(f"Luas lingkaran (jari-jari 7): {mo.luas_lingkaran(7):.2f}")
print(f"Keliling lingkaran (jari-jari 7): {mo.keliling_lingkaran(7):.2f}")

print("\n=== Konversi Suhu ===")
celsius = 25
print(f"{celsius}°C ke Fahrenheit: {celsius_ke_fahrenheit(celsius)}°F")
print(f"{celsius}°C ke Kelvin: {celsius_ke_kelvin(celsius)}K")