import { saveData, loadData } from './storage.js';

// === Classes ===
class Task {
  constructor(id, text, isDone = false) {
    this.id = id;
    this.text = text;
    this.isDone = isDone;
  }
}

// === Jadwal Kuliah ===
const scheduleInput = document.getElementById('scheduleInput');
const scheduleList = document.getElementById('scheduleList');

window.addSchedule = () => {
  const schedules = loadData('schedules');
  if (scheduleInput.value) {
    schedules.push(scheduleInput.value);
    saveData('schedules', schedules);
    scheduleInput.value = '';
    renderSchedule();
  }
};

window.deleteSchedule = (index) => {
  const schedules = loadData('schedules');
  schedules.splice(index, 1);
  saveData('schedules', schedules);
  renderSchedule();
};

const renderSchedule = () => {
  const schedules = loadData('schedules');
  scheduleList.innerHTML = '';
  schedules.forEach((item, index) => {
    scheduleList.innerHTML += `
      <li>${item} <button onclick="deleteSchedule(${index})">Hapus</button></li>
    `;
  });
};

// === To-Do List ===
const taskInput = document.getElementById('taskInput');
const taskList = document.getElementById('taskList');

window.addTask = () => {
  const tasks = loadData('tasks');
  if (taskInput.value) {
    const newTask = new Task(Date.now(), taskInput.value);
    tasks.push(newTask);
    saveData('tasks', tasks);
    taskInput.value = '';
    renderTasks();
  }
};

window.toggleTask = (id) => {
  const tasks = loadData('tasks');
  const task = tasks.find(t => t.id === id);
  if (task) task.isDone = !task.isDone;
  saveData('tasks', tasks);
  renderTasks();
};

window.deleteTask = (id) => {
  let tasks = loadData('tasks');
  tasks = tasks.filter(t => t.id !== id);
  saveData('tasks', tasks);
  renderTasks();
};

const renderTasks = () => {
  const tasks = loadData('tasks');
  taskList.innerHTML = '';
  tasks.forEach(task => {
    taskList.innerHTML += `
      <div class="task-item ${task.isDone ? 'done' : ''}">
        <p>${task.text}</p>
        <div>
          <button onclick="toggleTask(${task.id})">${task.isDone ? 'Undo' : 'Selesai'}</button>
          <button onclick="deleteTask(${task.id})">Hapus</button>
        </div>
      </div>
    `;
  });
};

// === Catatan ===
const noteInput = document.getElementById('noteInput');
const savedNote = document.getElementById('savedNote');

window.saveNote = () => {
  localStorage.setItem('note', noteInput.value);
  renderNote();
};

const renderNote = () => {
  savedNote.innerText = localStorage.getItem('note') || '';
};

// === Cuaca & Waktu ===
const weatherEl = document.getElementById('weather');
const timeEl = document.getElementById('time');

const fetchWeather = async () => {
  try {
    const response = await fetch('https://api.weatherapi.com/v1/current.json?key=demo&q=Jakarta');
    const data = await response.json();
    weatherEl.innerText = `Jakarta: ${data.current.temp_c}°C, ${data.current.condition.text}`;
  } catch (error) {
    weatherEl.innerText = 'Gagal memuat data cuaca';
  }
};

const updateTime = () => {
  const now = new Date();
  timeEl.innerText = `Waktu Sekarang: ${now.toLocaleTimeString()}`;
};

// === Init ===
renderSchedule();
renderTasks();
renderNote();
fetchWeather();
setInterval(updateTime, 1000);